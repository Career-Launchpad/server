'use strict';

const AWS = require('aws-sdk');

import { ApolloServer, ApolloError, ValidationError, gql } from 'apollo-server';
import RootQuery from './schema'

const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.graphQL = (event, context, callback) => {
  callback(null, {statusCode: 200, body: "Working"});
}


/*=> graphql(RootQuery, event.queryStringParameters.query)
  .then(
    result => callback(null, {statusCode: 200, body: JSON.stringify(result)}),
    err => callback(err)
  )*/
